﻿using Caliburn.Micro;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Markup;

namespace HebrewLanguageLearning_Users.ViewModels
{

    public class ShellViewModel : Conductor<object>,IHandle<ChangePageMessage>,IHandle<OpenWindowMessage>
    {
        public IEventAggregator EventAggregator { get; private set; }
        public IWindowManager WindowManager { get; private set; }

        public ShellViewModel(){ LoadLoginView(); }

        public void Handle(ChangePageMessage message)
        {
            var instance = IoC.GetInstance(message.ViewModelType, null);
            ActivateItem(instance);
        }

        public void Handle(OpenWindowMessage message)
        {
            var instance = IoC.GetInstance(message.ViewModelType, null);
            WindowManager.ShowWindow(instance);
        }
        
        public void LoadLoginView()
        {
            ActivateItem(new Account.LoginViewModel());
        }

        public void LoadDashboardView()
        {
            ActivateItem(new Dashboard.DashboardViewModel());
        }
        public void MenuIconOpen()
        {
            //SlideMenu
        }

    }
    public class ChangePageMessage
    {
        public readonly Type ViewModelType;

        public ChangePageMessage(Type viewModelType)
        {
            ViewModelType = viewModelType;
        }
    }
    public class OpenWindowMessage
    {
        public readonly Type ViewModelType;

        public OpenWindowMessage(Type viewModelType)
        {
            ViewModelType = viewModelType;
        }
    }

}
